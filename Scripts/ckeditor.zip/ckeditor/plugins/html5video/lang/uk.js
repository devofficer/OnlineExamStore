CKEDITOR.plugins.setLang( 'html5video', 'uk', {
    button: 'Вставити HTML5 відео',
    title: 'HTML5 відео',
    infoLabel: 'Інформація',
    allowed: 'Допустимі розширення файлів: MP4, WebM, Ogv',
    urlMissing: 'Не обрано джерела відео',
    videoProperties: 'Властивості відео',
    upload: 'Відвантажити',
    btnUpload: 'Відвантажити на сервер',
    advanced: 'Додатково',
    autoplay: 'Автовідтворення?',
    allowdownload: 'Allow download?',
    advisorytitle: 'Advisory title',
    yes: 'Так',
    no: 'Ні',
    controls: 'Показати елементи керування?'
} );
