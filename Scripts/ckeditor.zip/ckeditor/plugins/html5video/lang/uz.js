CKEDITOR.plugins.setLang( 'html5video', 'uz', {
    button: 'HTML5 video qo‘shing',
    title: 'HTML5 video',
    infoLabel: 'Video ma\'lumot',
    allowed: 'Ruxsat etilgan kengaytmalar: MP4, WebM, Ogv',
    urlMissing: 'Video\'ning URL manbasi topilmadi.',
    videoProperties: 'Video xususiyatlari',
    upload: 'Yuklash',
    btnUpload: 'Serverga jo‘natish',
    advanced: 'Kengaytrilgan',
    autoplay: 'Avtoijro?',
    allowdownload: 'Allow download?',
    advisorytitle: 'Advisory title',
    yes: 'Ha',
    no: 'Yo‘q',
    controls: 'Tekshiruvlarni ko‘rsatish'
} );
